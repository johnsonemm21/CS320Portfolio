import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskSuccessfully() {
        TaskService service = new TaskService();
        Task t = new Task("A1", "Task", "Description");
        service.addTask(t);

        assertEquals(1, service.getTaskCount());
        assertEquals("Task", service.getTask("A1").getName());
    }

    @Test
    void testAddDuplicateTaskIdThrows() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Task1", "Desc1"));

        assertThrows(IllegalArgumentException.class, () ->
            service.addTask(new Task("A1", "Task2", "Desc2"))
        );
    }

    @Test
    void testDeleteTaskSuccessfully() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Task", "Description"));

        service.deleteTask("A1");

        assertEquals(0, service.getTaskCount());
        assertNull(service.getTask("A1"));
    }

    @Test
    void testDeleteMissingTaskThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("NOPE"));
    }

    @Test
    void testUpdateTaskNameAndDescriptionSuccessfully() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Old Name", "Old Desc"));

        service.updateTask("A1", "New Name", "New Desc");

        Task updated = service.getTask("A1");
        assertEquals("New Name", updated.getName());
        assertEquals("New Desc", updated.getDescription());
    }

    @Test
    void testUpdateTaskOnlyName() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Old Name", "Old Desc"));

        service.updateTask("A1", "New Name", null);

        Task updated = service.getTask("A1");
        assertEquals("New Name", updated.getName());
        assertEquals("Old Desc", updated.getDescription());
    }

    @Test
    void testUpdateTaskOnlyDescription() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Old Name", "Old Desc"));

        service.updateTask("A1", null, "New Desc");

        Task updated = service.getTask("A1");
        assertEquals("Old Name", updated.getName());
        assertEquals("New Desc", updated.getDescription());
    }

    @Test
    void testUpdateMissingTaskThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask("NOPE", "Name", "Desc")
        );
    }

    @Test
    void testTaskIdNotUpdatableByService() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Name", "Desc"));

        service.updateTask("A1", "Name2", "Desc2");
        assertNotNull(service.getTask("A1"));
        assertEquals("A1", service.getTask("A1").getTaskId());
    }
}
