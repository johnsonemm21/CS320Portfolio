import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreatedSuccessfully() {
        Task t = new Task("12345", "Do Homework", "Finish CS 320 milestone");
        assertEquals("12345", t.getTaskId());
        assertEquals("Do Homework", t.getName());
        assertEquals("Finish CS 320 milestone", t.getDescription());
    }

    @Test
    void testTaskIdNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Name", "Description")
        );
    }

    @Test
    void testTaskIdTooLongThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345678901", "Name", "Description") // 11 chars
        );
    }

    @Test
    void testNameNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("123", null, "Description")
        );
    }

    @Test
    void testNameTooLongThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("123", "123456789012345678901", "Description") // 21 chars
        );
    }

    @Test
    void testDescriptionNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("123", "Name", null)
        );
    }

    @Test
    void testDescriptionTooLongThrows() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertEquals(51, longDesc.length());
        assertThrows(IllegalArgumentException.class, () ->
            new Task("123", "Name", longDesc)
        );
    }

    @Test
    void testUpdateNameSuccessfully() {
        Task t = new Task("1", "Old", "Desc");
        t.setName("New Name");
        assertEquals("New Name", t.getName());
    }

    @Test
    void testUpdateDescriptionSuccessfully() {
        Task t = new Task("1", "Name", "Old Desc");
        t.setDescription("New Desc");
        assertEquals("New Desc", t.getDescription());
    }

    @Test
    void testUpdateNameInvalidThrows() {
        Task t = new Task("1", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
    }

    @Test
    void testUpdateDescriptionInvalidThrows() {
        Task t = new Task("1", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
    }
}
