import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task must not be null.");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID must not be null.");
        }
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("No task found for ID: " + taskId);
        }
        tasks.remove(taskId);
    }

    public void updateTask(String taskId, String newName, String newDescription) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID must not be null.");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("No task found for ID: " + taskId);
        }

        if (newName != null) {
            task.setName(newName);
        }
        if (newDescription != null) {
            task.setDescription(newDescription);
        }
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    public int getTaskCount() {
        return tasks.size();
    }
}
