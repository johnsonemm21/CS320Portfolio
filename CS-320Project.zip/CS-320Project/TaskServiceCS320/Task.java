public class Task {
    private final String taskId;     
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10 || taskId.trim().isEmpty()) {
            throw new IllegalArgumentException("Task ID must not be null/empty and must be <= 10 characters.");
        }
        if (name == null || name.length() > 20 || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name must not be null/empty and must be <= 20 characters.");
        }
        if (description == null || description.length() > 50 || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must not be null/empty and must be <= 50 characters.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Updatable fields
    public void setName(String name) {
        if (name == null || name.length() > 20 || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name must not be null/empty and must be <= 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50 || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must not be null/empty and must be <= 50 characters.");
        }
        this.description = description;
    }
}
