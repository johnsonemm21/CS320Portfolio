import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 60_000);
    }

    @Test
    void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Desc");

        service.addAppointment(appt);

        assertEquals(1, service.getAppointmentCount());
        assertNotNull(service.getAppointment("A1"));
        assertEquals("A1", service.getAppointment("A1").getAppointmentId());
    }

    @Test
    void testAddAppointmentDuplicateIdThrows() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("A1", futureDate(), "Desc1");
        Appointment appt2 = new Appointment("A1", futureDate(), "Desc2");

        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    void testAddAppointmentNullThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Desc");
        service.addAppointment(appt);

        service.deleteAppointment("A1");

        assertEquals(0, service.getAppointmentCount());
        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteAppointmentNotFoundThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NOPE"));
    }

    @Test
    void testDeleteAppointmentNullThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}