import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 60_000); // 1 minute in future
    }

    @Test
    void testAppointmentCreationValid() {
        Appointment appt = new Appointment("A123", futureDate(), "Checkup appointment");
        assertEquals("A123", appt.getAppointmentId());
        assertEquals("Checkup appointment", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    void testAppointmentIdNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate(), "Desc")
        );
    }

    @Test
    void testAppointmentIdTooLongThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate(), "Desc") // 11 chars
        );
    }

    @Test
    void testAppointmentDateNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", null, "Desc")
        );
    }

    @Test
    void testAppointmentDatePastThrows() {
        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", past, "Desc")
        );
    }

    @Test
    void testDescriptionNullThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", futureDate(), null)
        );
    }

    @Test
    void testDescriptionTooLongThrows() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51
        assertEquals(51, longDesc.length());
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", futureDate(), longDesc)
        );
    }

    @Test
    void testSetAppointmentDateValid() {
        Appointment appt = new Appointment("A1", futureDate(), "Desc");
        Date later = new Date(System.currentTimeMillis() + 120_000);
        appt.setAppointmentDate(later);
        assertEquals(later.getTime(), appt.getAppointmentDate().getTime());
    }

    @Test
    void testSetAppointmentDatePastThrows() {
        Appointment appt = new Appointment("A1", futureDate(), "Desc");
        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(past));
    }

    @Test
    void testSetDescriptionValid() {
        Appointment appt = new Appointment("A1", futureDate(), "Desc");
        appt.setDescription("Updated description");
        assertEquals("Updated description", appt.getDescription());
    }

    @Test
    void testSetDescriptionTooLongThrows() {
        Appointment appt = new Appointment("A1", futureDate(), "Desc");
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(longDesc));
    }
}