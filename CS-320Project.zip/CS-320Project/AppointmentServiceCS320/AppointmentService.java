import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment must not be null.");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }
        appointments.put(id, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || appointmentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment ID must not be null or empty.");
        }
        // Common approach: throw if not found (clear feedback for tests)
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointments.remove(appointmentId);
    }

    // Helper methods often allowed for testing (not required, but useful)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    public int getAppointmentCount() {
        return appointments.size();
    }
}