import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact c = new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi");

        service.addContact(c);

        Contact fetched = service.getContact("042503");
        assertNotNull(fetched);
        assertEquals("Emma", fetched.getFirstName());
    }

    @Test
    public void testAddContactDuplicateIdFails() {
        ContactService service = new ContactService();
        service.addContact(new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(new Contact("042503", "John", "Smith", "0987654321", "456 Oak Ave"))
        );
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        service.addContact(new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));

        service.deleteContact("042503");

        assertNull(service.getContact("042503"));
    }

    @Test
    public void testDeleteContactMissingIdFails() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    public void testUpdateContactFields() {
        ContactService service = new ContactService();
        service.addContact(new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));

        service.updateFirstName("042503", "Em");
        service.updateLastName("042503", "Jo");
        service.updatePhoneNumber("042503", "7154710658");
        service.updateAddress("042503", "4860N Ranch Dr");

        Contact updated = service.getContact("042503");
        assertEquals("Em", updated.getFirstName());
        assertEquals("Jo", updated.getLastName());
        assertEquals("7154710658", updated.getPhoneNumber());
        assertEquals("4860N Ranch Dr", updated.getAddress());
    }

    @Test
    public void testUpdateMissingContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("404", "Jo"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("404", "Smi"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber("404", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("404", "Somewhere"));
    }
}