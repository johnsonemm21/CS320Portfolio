import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	@Test
	public void testContactCreationValid() {
		Contact c = new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi");
		assertEquals("042503", c.getContactID());
		assertEquals("Emma", c.getFirstName());
		assertEquals("Johnson", c.getLastName());
		assertEquals("7154710658", c.getPhoneNumber());
		assertEquals("4860N Ranch Dr, Stone Lake Wi", c.getAddress());
	}
	
	@Test
	public void testContactIDNull() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact(null, "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testContactIDTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042520032021", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testFirstNameNull() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", null, "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma Emma Jo", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testLastNameNull() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", null, "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", " Jo Johnson ", "7154710658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testPhoneNumberNull() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", null, "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testPhoneNumberNotTenDigits() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", "+17154710658", "4860N Ranch Dr, Stone Lake Wi"));
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", "4710658", "4860N Ranch Dr, Stone Lake Wi"));
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", "cell: (715)471-0658", "4860N Ranch Dr, Stone Lake Wi"));
	}
	
	@Test
	public void testAddressNull() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", "7154710658", null));
	}
	
	@Test
	public void testAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
				new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake WI, 54876"));
	}
	
	@Test
	public void testSettersValidate() {
		Contact c = new Contact("042503", "Emma", "Johnson", "7154710548", "4860N Ranch Dr, Stone Lake WI");
		
		assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
		assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
		assertThrows(IllegalArgumentException.class, () -> c.setPhoneNumber(null));
		assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
	}
	
	@Test
	public void testUpdateFieldsValid() {
		Contact c = new Contact("042503", "Emma", "Johnson", "7154710658", "4860N Ranch Dr, Stone Lake, WI");
		c.setFirstName("Em");
		c.setLastName("Jo");
		c.setPhoneNumber("7154710658");
		c.setAddress("4860N Ranch Dr, Stone Lake Wi");
		
		assertEquals("Em", c.getFirstName());
		assertEquals("Jo", c.getLastName());
		assertEquals("7154710658", c.getPhoneNumber());
		assertEquals("4860N Ranch Dr, Stone Lake Wi", c.getAddress());
	}
}