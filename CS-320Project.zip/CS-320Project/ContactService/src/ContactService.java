import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	private Map<String, Contact> contacts = new HashMap<>();
	
	public void addContact(Contact contact) {
		if(contact == null) {
			throw new IllegalArgumentException("Contact must not be null");
		}
		
		String id = contact.getContactID();
		if (id == null || id.trim().isEmpty()) {
		    throw new IllegalArgumentException("Contact ID must not be null or empty");
		}
		
		if (contacts.containsKey(id)) {
		    throw new IllegalArgumentException("Contact ID already exists: " + id);
		}
		
		contacts.put(id, contact);
	}
	
	public void deleteContact(String contactID) {
		if (contactID == null || contactID.trim().isEmpty()) {
			throw new IllegalArgumentException("Contact ID must not me null or empty");
		}
		if(!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("Contact ID not found: " + contactID);
		}
		
		contacts.remove(contactID);
	}
	
	public Contact getContact(String contactID) {
	    if (contactID == null || contactID.trim().isEmpty()) {
	        throw new IllegalArgumentException("Contact ID cannot be null or empty");
	    }
	    return contacts.get(contactID);
	}
	
	public void updateFirstName(String contactID, String firstName) {
		Contact c = getExisting(contactID);
		c.setFirstName(firstName);
	}
	
	public void updateLastName(String contactID, String lastName) {
		Contact c = getExisting(contactID);
		c.setLastName(lastName);
	}
	
	public void updatePhoneNumber(String contactID, String phoneNumber) {
		Contact c = getExisting(contactID);
		c.setPhoneNumber(phoneNumber);
	}
	
	public void updateAddress(String contactID, String address) {
		Contact c = getExisting(contactID);
		c.setAddress(address);
	}
	
	private Contact getExisting(String contactID) {
	    if (contactID == null || contactID.trim().isEmpty()) {
	        throw new IllegalArgumentException("Contact ID must not be null or empty");
	    }

	    Contact c = contacts.get(contactID);
	    if (c == null) {
	        throw new IllegalArgumentException("Contact ID not found: " + contactID);
	    }

	    return c;
	}
}