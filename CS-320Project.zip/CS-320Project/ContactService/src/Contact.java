public class Contact {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		validateContactID(contactID);
		validateFirstName(firstName);
		validateLastName(lastName);
		validatePhoneNumber(phoneNumber);
		validateAddress(address);
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setFirstName(String firstName) {
		validateFirstName(firstName);
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		validateLastName(lastName);
		this.lastName = lastName;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		validatePhoneNumber(phoneNumber);
		this.phoneNumber = phoneNumber;
	}
	public void setAddress(String address) {
		validateAddress(address);
		this.address = address;
	}
	
	private static void validateContactID(String contactID) {
		if (contactID == null || contactID.trim().isEmpty()) {
			throw new IllegalArgumentException("Contact ID must not be null/empty");
		}
		if(contactID.length() > 10) {
			throw new IllegalArgumentException("Contact ID must not be longer than 10 characters");
		}
	}
	
	private static void validateFirstName(String firstName) {
		if (firstName == null || firstName.trim().isEmpty()) {
			throw new IllegalArgumentException("First Name must not be null/empty");
		}
		if(firstName.length() > 10) {
			throw new IllegalArgumentException("First Name must not be longer than 10 characters");
		}
	}
	
	private static void validateLastName(String lastName) {
		if(lastName == null || lastName.trim().isEmpty()) {
			throw new IllegalArgumentException("Last Name must not be null/empty");
		}
		if(lastName.length() > 10) {
			throw new IllegalArgumentException("Last Name must not be longer than 10 characters");
		}
	}
	
	private static void validatePhoneNumber(String phoneNumber) {
	    if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
	        throw new IllegalArgumentException("Phone Number must not be null/empty");
	    }
	    if (phoneNumber.length() != 10) {
	        throw new IllegalArgumentException("Phone Number must be exactly 10 digits");
	    }
	    if (!phoneNumber.matches("\\d{10}")) {
	        throw new IllegalArgumentException("Phone Number must contain digits only");
	    }
	}
	
	private static void validateAddress(String address) {
		if(address == null || address.trim().isEmpty()) {
			throw new IllegalArgumentException("Address must not be null/empty");
		}
		if(address.length() > 30) {
			throw new IllegalArgumentException("Address must not be longer than 30 characters");
		}
	}
	
}